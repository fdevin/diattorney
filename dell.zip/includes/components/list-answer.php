<?php
/**
 * List Answer
 * @package WordPress
 * @subpackage Dell
 * @version 1.0
*/
?>
<ul class="dell-list-img dell-list-answer">
    <li>
        <div class="dell-list-img-col-1">
            <img src="img/avatars/100.png" alt="" width="100" />
        </div>
        <div class="dell-list-img-col-2">
            <h3>Q: How Doe Mutual of Omaha Define Disability?</h3>
            <small>Answered yesterday by <a href="#">Attorney Alex Palamara</a></small>
            <p><strong>A:</strong>Mutual of Omaha disability poicy is very lengthy. Learn what you need to kmow to havea better understanding... <a href="#">read more></a></p>
            <ul class="dell-related">
                <p>Related:</p>
                <li>
                    <a href="#">Lawsuits & Claim Tips</a>
                </li>
                <li>
                    <a href="#">Mutual of Omaha</a>
                </li>
            </ul>
        </div>
    </li>
</ul>