<?php
/**
 * Card Small
 * @package WordPress
 * @subpackage Dell
 * @version 1.0
*/
?>
<div class="dell-card-small">
    <img src="img/thumb.jpg" alt="" />
    <div class="dell-card-small-body">
        <h5 class="dell-card-small-title">Legal Help: Mutual of Omaha LTD Insurance Denial, Appeal & Lawsuits</h5>
        <h6 class="dell-card-small-subtitle">September 2, 2020</h6>
    </div>
</div>