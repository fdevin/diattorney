<?php
/**
 * Player
 * @package WordPress
 * @subpackage Dell
 * @version 1.0
*/
?>
<div class="dell-player">
    <img src="img/player/1.jpg" alt="" />
    <button type="button">
        <img src="img/icons/play.svg" width="60" alt="play" />
    </button>
    <iframe src="https://www.youtube.com/embed/Dyvb8tLVhzI?rel=0" allowfullscreen style="display: none;"></iframe>
</div>